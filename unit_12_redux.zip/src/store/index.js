import { configureStore } from '@redux-toolkit';
import goodsReducer from './goodsSlice';


export default configureStore({
    reducer: {
        goods: goodsReducer,
    },
});