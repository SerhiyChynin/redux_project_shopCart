import GoodsList from "./container/GoodsList";


function App() {
  return (
    <div>
      {/* вывод данных из хранилища */}
      <div className="goods-field">
        <GoodsList/>

      </div>
    </div>
  );
}

export default App;
